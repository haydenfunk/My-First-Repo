class Employee {
    constructor(name, salary, hireDate) {
      this.name = name;
      this.salary = salary;
      this.hireDate = hireDate;
    }
    getName() {
      console.log(this.name.toUpperCase());
    }
    getSalary() {
      console.log(this.salary);
    }
    getHireDate() {
      console.log(this.hireDate);
    }
  }

class Manager extends Employee {
      constructor(descriptionOfJob, name, salary, hireDate) {
          super(name, salary, hireDate);
          this.descriptionOfJob = descriptionOfJob;
      }
      jobDescription() {
          console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because he " + this.descriptionOfJob);
  }
}
class Designer extends Employee {
    constructor(experience, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.experience = experience;
    }
    yearsExperience() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because he has " + this.experience);
}
}
class SalesAssociate extends Employee {
    constructor(degree, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.degree = degree;
    }
    degreesCompleted() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because she has a " + this.degree);
}
}
let andrew = new Manager("manages the sales staff.", "Andrew", 80000, "1/19/19");
let mike = new Designer("5 years experience.", "Mike", 65400, "1/30/19");
let sam = new SalesAssociate("Business degree.", "Samantha", 60000, "1/8/19");
andrew.jobDescription();
mike.yearsExperience();
sam.degreesCompleted();
