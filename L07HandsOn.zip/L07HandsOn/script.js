function regexChecker()
var regexName = /^[A-Z]/;
var firstName = document.getElementById("first").value;
var lastName = document.getElementById("last").value;

if(firstName.match(regexName) && firstName.length>1){
    if(lastName.match(regexName) && lasttName.length>1){
        document.getElementById("result").innerHTML = "Yay! Your inputs were all correct!"
    }
}
else document.getElementById("result").innerHTML = "Oh no! Thats an invalid format!";